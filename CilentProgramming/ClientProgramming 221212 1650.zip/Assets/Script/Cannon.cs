using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannon : MonoBehaviour
{
    public GameObject objBullet;
    public GameObject ShotPos;

    public float shotCooltime = 3f;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Shot(Vector3.forward);
    }

    void Shot(Vector3 dir)
    {
        if (shotCooltime > 0)
            shotCooltime -= Time.deltaTime;
        if (shotCooltime <= 0)
        {
            GameObject copybullet = Instantiate(objBullet, ShotPos.transform.position, Quaternion.identity);
            Rigidbody rigidbody = copybullet.GetComponent<Rigidbody>();

            shotCooltime = 3f;
        }
    }
}
