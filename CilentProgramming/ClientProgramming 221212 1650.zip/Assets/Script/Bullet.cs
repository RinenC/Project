using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float power;
    public float ShotDist;
    public Vector3 StartPos;
    // Start is called before the first frame update
    void Start()
    {
        StartPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        ShotDestroy();
    }

    void Move()
    {
        transform.position += Vector3.forward * power * Time.deltaTime;
    }

    void ShotDestroy()
    {
        float dist = Vector3.Distance(StartPos, transform.position);
        if(dist >= ShotDist)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            Vector3 dirvec = collision.transform.position - transform.position;
            collision.gameObject.GetComponent<Rigidbody>().AddForce(dirvec * 100000);
        }
    }
}
