using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoSingleton<GameManager>
{
    public bool keyA;
    public bool keyB;

    public bool ButtonDown;

    public bool PlayerDeath;

    public move Player;
    public Openplatform Openplatform;

    public Transform spawnpoint;
}
