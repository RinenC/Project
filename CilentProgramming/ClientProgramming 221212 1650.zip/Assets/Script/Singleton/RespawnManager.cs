using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnManager : MonoSingleton<RespawnManager>
{
    public GameObject resobject;
    public GameObject target;

    float deathtime = 2f;

    public void Start()
    {
        Respawn();
    }

    void Update()
    {
        Respawn();

        if(Input.GetKeyDown(KeyCode.R))
        {
            GameManager.Instance.PlayerDeath = true;
        }
    }

    void Respawn()
    {
        if (target == null)
        {
            target = Instantiate(resobject, GameManager.Instance.spawnpoint.position, Quaternion.identity);
            Debug.Log("Respawn");
        }
        if (GameManager.Instance.PlayerDeath == true)
        {
            if (deathtime > 0)
                deathtime -= Time.deltaTime;
            if (deathtime <= 0)
            {
                Destroy(target.gameObject);
                GameManager.Instance.PlayerDeath = false;
                deathtime = 2f;
            }
        }
    }
}
