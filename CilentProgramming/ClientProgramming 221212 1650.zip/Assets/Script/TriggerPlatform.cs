using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerPlatform : MonoBehaviour
{
    public Material materialM;
    void Start()
    {
        gameObject.GetComponent<BoxCollider>().isTrigger = true;
    }

    void Update()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            this.GetComponent<BoxCollider>().isTrigger = false;
            Material[] material = this.GetComponent<MeshRenderer>().materials;
            material[0] = materialM;
            this.GetComponent<MeshRenderer>().materials = material;
            if (this.gameObject.CompareTag("Stinger"))
            {
                GameManager.Instance.PlayerDeath = true;
            }
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (this.gameObject.CompareTag("Stinger"))
        {
            GameManager.Instance.PlayerDeath = true;
        }
    }
}
