using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public float ShotDist;
    public Vector3 StartPos;
    // Start is called before the first frame update
    void Start()
    {
        StartPos = transform.position;
        gameObject.GetComponent<Rigidbody>().AddForce(Vector3.forward * 100);
    }

    // Update is called once per frame
    void Update()
    {
        BallDestroy();
    }

    void BallDestroy()
    {
        float dist = Vector3.Distance(StartPos, transform.position);
        if (dist >= ShotDist)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Vector3 dirvec = collision.transform.position - transform.position;
            collision.gameObject.GetComponent<Rigidbody>().AddForce(dirvec * 10000);
        }
    }
}
