using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Openplatform : MonoBehaviour
{
    public float speed;
    float i;
    public bool isTrigger;
    public GameObject AxisLeft;
    public GameObject AxisRight;

    void Start()
    {

    }

    void Update()
    {
        CheckRaycast();
        OpenProcess();
    }

    private void OpenProcess()
    {
        if (isTrigger)
        {
            if (i < 120)
            {
                i += Time.deltaTime * speed;
                AxisLeft.transform.rotation = Quaternion.Euler(0f, 0f, -i);
                AxisRight.transform.rotation = Quaternion.Euler(0f, 0f, i);
            }
            if (i >= 120)
            {
                i = 0;
                AxisLeft.transform.rotation = Quaternion.Euler(0, 0f, -i);
                AxisRight.transform.rotation = Quaternion.Euler(0, 0f, i);
                isTrigger = false;
            }
        }
    }

    private void CheckRaycast()
    {
        RaycastHit raycastHit;
        int Ray = 1 << LayerMask.NameToLayer("Player");
        if (Physics.BoxCast(transform.position, new Vector3(1.5f, 0.2f, 1.5f), transform.up, out raycastHit, Quaternion.identity, 0.3f, Ray, QueryTriggerInteraction.Ignore))
        {
            isTrigger = true;
        }
    }

    public void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(transform.position, new Vector3(3f, 1f, 3f));
    }
}
