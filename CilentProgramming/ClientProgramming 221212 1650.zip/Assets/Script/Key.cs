using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Key : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player")) 
        {
            if (this.gameObject.CompareTag("KeyA"))
            {
                GameManager.Instance.keyA = true;
                Destroy(this.gameObject);
            }
            if (this.gameObject.CompareTag("KeyB"))
            {
                GameManager.Instance.keyB = true;
                Destroy(this.gameObject);
            }
        }
    }
}
