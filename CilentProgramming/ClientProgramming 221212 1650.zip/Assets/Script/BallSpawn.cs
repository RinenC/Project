using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallSpawn : MonoBehaviour
{
    public GameObject Ball;

    public GameObject AxisLeft;
    public GameObject AxisRight;

    public float spawnCooltime = 2f;

    int random;

    void Start()
    {

    }

    void Update()
    {
        RandomInt();
        SpawnBall();
    }

    void RandomInt()
    {
        random = Random.Range(0, 2);
    }

    void SpawnBall()
    {
        if (spawnCooltime > 0)
            spawnCooltime -= Time.deltaTime;
        if (spawnCooltime <= 0)
        {
            if (random == 0)
            {
                GameObject copyball = Instantiate(Ball, AxisLeft.transform.position, Quaternion.identity);
            }
            if (random == 1)
            {
                GameObject copyball = Instantiate(Ball, AxisRight.transform.position, Quaternion.identity);
            }
            spawnCooltime = 2f;
        }
    }
}
