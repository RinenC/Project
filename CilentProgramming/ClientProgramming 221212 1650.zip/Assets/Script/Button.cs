using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour
{
    public Material materialM;

    void Start()
    {
        gameObject.GetComponent<BoxCollider>().isTrigger = true;
    }

    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        this.transform.position -= new Vector3(0f, 0.2f, 0f);

        this.GetComponent<BoxCollider>().isTrigger = false;
        Material[] material = this.GetComponent<MeshRenderer>().materials;
        material[0] = materialM;
        this.GetComponent<MeshRenderer>().materials = material;

        GameManager.Instance.ButtonDown = true;
    }
}
