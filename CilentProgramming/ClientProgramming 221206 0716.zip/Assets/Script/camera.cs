using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour
{
    public Transform target;
    public float speed = 1f;
    Vector3 pos;
    public float Height;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (target != null)
        {
            pos = new Vector3(target.transform.position.x, target.transform.position.y + Height, target.transform.position.z - 10f);
            transform.position = Vector3.Lerp(transform.position, pos, speed * Time.deltaTime);
        }
        else
        {
            transform.position = transform.position;
        }
    }
}
