using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            if(GameManager.Instance.keyA = true && GameManager.Instance.keyB == true)
            {
                Destroy(other.gameObject);
                Debug.Log("Clear!");
            }
        }

    }
}
