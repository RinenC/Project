using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapPlatform : MonoBehaviour
{
    public float time = 10f;
    public Material matecha;
    public Color tempColor;

    float cooltime = 1f;

    void Start()
    {
        matecha = this.GetComponent<MeshRenderer>().material;
    }


    void Update()
    {
        Trap();
    }

    void Trap()
    {
        if (time > 0)
        {
            tempColor = matecha.color;
            tempColor.a = matecha.color.a - Time.deltaTime / time;
            matecha.color = tempColor;

            time -= Time.deltaTime;

            this.GetComponent<BoxCollider>().isTrigger = false;
        }
        if (time <= 0)
        {
            if (cooltime > 0)
            {
                cooltime -= Time.deltaTime;
                this.GetComponent<BoxCollider>().isTrigger = true;
            }
            if (cooltime <= 0)
            {
                cooltime = 1f;
                time = 3f;

                tempColor = matecha.color;
                tempColor.a = 1f;
                matecha.color = tempColor;
            }
        }
    }
}
