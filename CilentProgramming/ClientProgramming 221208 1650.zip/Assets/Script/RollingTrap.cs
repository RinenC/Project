using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RollingTrap : MonoBehaviour
{
    public float speed = 10f;
    float i;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Rolling();
    }

    void Rolling()
    {
        i += Time.deltaTime * speed;
        transform.rotation = Quaternion.Euler(0f, i, 0f);
    }
}
