using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    public Transform trTargetPoint;
    public Transform trRespawnPoint;
    public Transform trPatrolPoint;

    public float speed = 10f;

    void Start()
    {
        
    }

    void Update()
    {
        TargetSetting();
        PlatformMovingProcess();
    }

    void PlatformMovingProcess()
    {
        if (GameManager.Instance.ButtonDown)
        {
            if (trTargetPoint)
            {
                Vector3 vTargetPos = trTargetPoint.position;
                Vector3 vPos = this.transform.position;
                Vector3 vDist = vTargetPos - vPos;//��ġ�� ���̸� �̿��� �Ÿ����ϱ�
                Vector3 vDir = vDist.normalized;//�ι�ü������ ����(����ȭ-�Ÿ����� �̵���)
                float fDist = vDist.magnitude; //�ι�ü������ �Ÿ�(��Į��-�����̵���)

                if (fDist > Time.deltaTime)//���������� �̵��Ÿ����� Ŭ���� �̵��Ѵ�.
                {
                    transform.position += vDir * speed * Time.deltaTime;
                }
            }
        }
    }

    void TargetSetting()
    {
        float PosA = Vector3.Distance(this.transform.position, trPatrolPoint.position);
        float PosB = Vector3.Distance(this.transform.position, trRespawnPoint.position);
        if (PosA <= 0.2f)
            trTargetPoint = trRespawnPoint;
        else if (PosB <= 0.2f)
            trTargetPoint = trPatrolPoint;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            collision.transform.parent = this.transform;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            collision.transform.parent = null;
        }
    }
}
