using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    public Animator animator;

    public float speed = 10f;
    public float jumpPower = 10f;
    Rigidbody rigidbody;
    Vector3 movement;
    float h;
    float v;

    bool isJump;
    public bool isMove;

    // Start is called before the first frame update
    void Awake()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        h = Input.GetAxisRaw("Horizontal");
        v = Input.GetAxisRaw("Vertical");
        MoveProcess();
        Run(h, v);
        AnimationUpdate();
    }

    private void FixedUpdate()
    {

    }

    private void MoveProcess()
    {
        if (!GameManager.Instance.PlayerDeath)
        {
            if (Input.GetKey(KeyCode.RightArrow))
            {
                transform.position += Vector3.right * speed * Time.deltaTime;
                isMove = true;
            }
            if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 90, 0));
            }
            if (Input.GetKey(KeyCode.LeftArrow))
            {
                transform.position -= Vector3.right * speed * Time.deltaTime;
                isMove = true;
            }
            if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, -90, 0));
            }
            if (Input.GetKey(KeyCode.UpArrow))
            {
                transform.position += Vector3.forward * speed * Time.deltaTime;
                isMove = true;
            }
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
            }
            if (Input.GetKey(KeyCode.DownArrow))
            {
                transform.position -= Vector3.forward * speed * Time.deltaTime;
                isMove = true;
            }
            if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 180, 0));
            }
            if (Input.GetKeyDown(KeyCode.Space))
            {
                if (!isJump)
                {
                    rigidbody.AddForce(Vector3.up * jumpPower);
                    isJump = true;
                    isMove = true;
                }
            }
            if (Input.GetKeyUp(KeyCode.RightArrow) || Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.UpArrow) || Input.GetKeyUp(KeyCode.DownArrow) || Input.GetKeyUp(KeyCode.Space))
            {
                isMove = false;
            }
        }
    }

    void Run(float h, float v)
    {
        movement.Set(h, 0, v);
        movement = movement.normalized * speed * Time.deltaTime;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Map") || collision.gameObject.CompareTag("TriggerPlatform"))
        {
            isJump = false;
        }
    }

    private void AnimationUpdate()
    {
        if (isMove)
            animator.SetBool("Move", true);
        else
            animator.SetBool("Move", false);

        if (GameManager.Instance.PlayerDeath)
            animator.SetBool("Death", true);
        else
            animator.SetBool("Death", false);
    }
}
