using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapPlatform : MonoBehaviour
{
    public float time = 10f;
    public Color color;
    public Material material;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        TriggerTime();
    }

    void TriggerTime()
    {
        color.a -= Time.deltaTime / time;
        //color.a = material.color;

        //if (color.a <= 0)
        //{
        //    this.GetComponent<BoxCollider>().isTrigger = true;
        //}
        //else
        //{
        //    color.a -= Time.deltaTime / time;
        //}

        //if(this.GetComponent<BoxCollider>().isTrigger == true)
        //{
        //    color.a += Time.deltaTime;
        //    this.GetComponent<BoxCollider>().isTrigger = false;
        //}

        Debug.Log(color.a);
    }
}
